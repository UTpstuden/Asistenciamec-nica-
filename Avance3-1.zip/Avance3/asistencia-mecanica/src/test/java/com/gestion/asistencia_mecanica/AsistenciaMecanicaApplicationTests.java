package com.gestion.asistencia_mecanica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsistenciaMecanicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
