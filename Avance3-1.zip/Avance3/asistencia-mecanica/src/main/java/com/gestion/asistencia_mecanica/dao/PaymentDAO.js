const db = require('../config/db');
const Payment = require('../models/Payment');

class PaymentDAO {
    async registerPayment(payment) {
        const [result] = await db.query(
            'INSERT INTO payments (service_request_id, amount, method, status, paid_at) VALUES (?, ?, ?, ?, ?)',
            [payment.serviceRequestId, payment.amount, payment.method, payment.status, payment.paidAt]
        );
        payment.id = result.insertId;
        return payment;
    }

    async findByServiceRequest(serviceRequestId) {
        const [rows] = await db.query('SELECT * FROM payments WHERE service_request_id = ?', [serviceRequestId]);
        return rows.map(p => new Payment(p.id, p.service_request_id, p.amount, p.method, p.status, p.paid_at));
    }
}

module.exports = new PaymentDAO();