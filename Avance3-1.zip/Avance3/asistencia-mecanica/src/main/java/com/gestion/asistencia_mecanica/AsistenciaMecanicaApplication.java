package com.gestion.asistencia_mecanica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsistenciaMecanicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsistenciaMecanicaApplication.class, args);
	}

}
