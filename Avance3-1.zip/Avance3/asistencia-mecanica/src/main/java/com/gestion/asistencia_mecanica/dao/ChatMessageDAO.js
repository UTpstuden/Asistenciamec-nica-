const db = require('../config/db');
const ChatMessage = require('../models/ChatMessage');

class ChatMessageDAO {
    async sendMessage(message) {
        const [result] = await db.query(
            'INSERT INTO chat_messages (sender_id, receiver_id, message, timestamp) VALUES (?, ?, ?, ?)',
            [message.senderId, message.receiverId, message.message, message.timestamp]
        );
        message.id = result.insertId;
        return message;
    }

    async getConversation(user1, user2) {
        const [rows] = await db.query(
            'SELECT * FROM chat_messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp ASC',
            [user1, user2, user2, user1]
        );
        return rows.map(m => new ChatMessage(m.id, m.sender_id, m.receiver_id, m.message, m.timestamp));
    }
}

module.exports = new ChatMessageDAO();