package com.gestion.asistencia_mecanica.controllers;

// Importaciones necesarias para Spring Boot
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gestion.asistencia_mecanica.dao.UsuarioDAO; // Asegúrate de ajustar el paquete correcto
import com.gestion.asistencia_mecanica.models.Usuario;   // Asegúrate de ajustar el paquete correcto

@Controller
public class AutenticacionController {

    private final UsuarioDAO usuarioDAO;


    public AutenticacionController(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    // Maneja la solicitud GET para mostrar el formulario de login
    @GetMapping("/login")
    public String mostrarFormularioLogin() {
        return "login"; // Devuelve el nombre de la vista HTML (login.html)
    }

    // Maneja la solicitud POST para procesar el login
    @PostMapping("/login")
    public String iniciarSesion(@RequestParam String email,
                                @RequestParam String contrasena,
                                Model model) { // El objeto Model se usa para pasar datos a la vista

       // 1. Corrige el uso de Optional: Usa .orElse(null) para obtener el Usuario o null
        Optional<Usuario> usuarioOptional = usuarioDAO.findByEmail(email);
        Usuario usuario = usuarioOptional.orElse(null); // Si el Optional está vacío, 'usuario' será null
        // Verifica las credenciales
        if (usuario == null || !usuario.getContrasena().equals(contrasena)) {
            model.addAttribute("error", "Credenciales inválidas"); // Agrega un mensaje de error al modelo
            return "login"; // Vuelve a la vista de login con el error
        }

        // Si las credenciales son válidas, pasa el usuario al dashboard
        model.addAttribute("usuario", usuario); // Agrega el objeto usuario al modelo
        return "dashboard-cliente"; // Redirige o renderiza la vista del dashboard del cliente
    }
}