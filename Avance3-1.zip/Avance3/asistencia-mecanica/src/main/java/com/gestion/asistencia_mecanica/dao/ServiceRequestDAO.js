const db = require('../config/db');
const ServiceRequest = require('../models/ServiceRequest');

class ServiceRequestDAO {
    async create(request) {
        const [result] = await db.query(
            'INSERT INTO service_requests (client_id, mechanic_id, description, status, created_at) VALUES (?, ?, ?, ?, ?)',
            [request.clientId, request.mechanicId, request.description, request.status, request.createdAt]
        );
        request.id = result.insertId;
        return request;
    }

    async findByClientId(clientId) {
        const [rows] = await db.query('SELECT * FROM service_requests WHERE client_id = ?', [clientId]);
        return rows.map(r => new ServiceRequest(r.id, r.client_id, r.mechanic_id, r.description, r.status, r.created_at));
    }
}

module.exports = new ServiceRequestDAO();