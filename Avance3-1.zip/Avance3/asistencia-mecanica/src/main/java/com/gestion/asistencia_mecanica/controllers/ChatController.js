const ChatMessageDAO = require('../dao/ChatMessageDAO');
const ChatMessage = require('../models/ChatMessage');

exports.sendMessage = async (req, res) => {
    const { senderId, receiverId, message } = req.body;
    const msg = new ChatMessage(null, senderId, receiverId, message, new Date());
    const saved = await ChatMessageDAO.sendMessage(msg);
    res.json(saved);
};