package com.gestion.asistencia_mecanica.models;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MensajeChat {
    private String idMensaje; // Identificador único del mensaje
    private String idRemitente; // ID del usuario que envió el mensaje
    private String idReceptor; // ID del usuario que recibe el mensaje
    private String contenidoMensaje; // Contenido textual del mensaje
    private long marcaDeTiempo; // Marca de tiempo (en milisegundos desde la época)
}