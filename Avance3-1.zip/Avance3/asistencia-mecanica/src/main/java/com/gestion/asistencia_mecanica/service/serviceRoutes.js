const express = require('express');
const router = express.Router();
const ServiceController = require('../controllers/ServiceController');

router.post('/create', ServiceController.createRequest);

module.exports = router;