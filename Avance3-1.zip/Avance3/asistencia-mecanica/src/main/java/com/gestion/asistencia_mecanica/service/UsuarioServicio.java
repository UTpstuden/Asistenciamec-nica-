package com.gestion.asistencia_mecanica.service; // O en tu controlador, por ejemplo

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.gestion.asistencia_mecanica.dao.UsuarioDAO;
import com.gestion.asistencia_mecanica.models.Usuario;

@Service // Marca esta clase como un componente de servicio de Spring
public class UsuarioServicio {

    private final UsuarioDAO usuarioDAO;

    public UsuarioServicio(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    /**
     * Busca un usuario por su ID.
     * @param id El ID del usuario a buscar.
     * @return Un Optional que contiene el Usuario si se encuentra, o un Optional vacío si no.
     */
    public Optional<Usuario> buscarUsuarioPorId(String id) {
        return usuarioDAO.findById(id); // Este método viene de JpaRepository
    }

    /**
     * Ejemplo de uso del método findByEmail.
     * @param email El email del usuario a buscar.
     * @return Un Optional que contiene el Usuario si se encuentra, o un Optional vacío si no.
     */
    public Optional<Usuario> buscarUsuarioPorEmail(String email) {
        return usuarioDAO.findByEmail(email);
    }

    /**
     * Guarda un nuevo usuario o actualiza uno existente.
     * @param usuario El objeto Usuario a guardar.
     * @return El usuario guardado/actualizado.
     */
    public Usuario guardarUsuario(Usuario usuario) {
        return usuarioDAO.save(usuario); // Este método también viene de JpaRepository
    }
}