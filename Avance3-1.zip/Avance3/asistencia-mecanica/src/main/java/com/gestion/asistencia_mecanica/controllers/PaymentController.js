const PaymentDAO = require('../dao/PaymentDAO');
const Payment = require('../models/Payment');

exports.makePayment = async (req, res) => {
    const { serviceRequestId, amount, method } = req.body;
    const payment = new Payment(null, serviceRequestId, amount, method, 'pagado', new Date());
    const saved = await PaymentDAO.registerPayment(payment);
    res.json(saved);
};