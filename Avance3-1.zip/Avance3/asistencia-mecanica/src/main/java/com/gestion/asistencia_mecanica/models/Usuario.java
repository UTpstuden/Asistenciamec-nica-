package com.gestion.asistencia_mecanica.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    private String idUsuario;
    private String nombre;
    private String email;
    private String contrasena;
    private String rol;


}