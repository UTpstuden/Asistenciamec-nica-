package com.gestion.asistencia_mecanica.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestion.asistencia_mecanica.models.Usuario; // Importación necesaria para Optional

@Repository
public interface UsuarioDAO extends JpaRepository<Usuario, String> { // El segundo tipo, 'String', es el tipo de la clave primaria (idUsuario)

    Optional<Usuario> findByEmail(String email);

    // ¡No necesitas añadir un método findById aquí!
    // JpaRepository ya lo provee automáticamente.
}