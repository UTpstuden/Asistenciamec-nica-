const ServiceRequestDAO = require('../dao/ServiceRequestDAO');
const ServiceRequest = require('../models/ServiceRequest');

exports.createRequest = async (req, res) => {
    const { clientId, mechanicId, description } = req.body;
    const request = new ServiceRequest(null, clientId, mechanicId, description, 'pendiente', new Date());
    const saved = await ServiceRequestDAO.create(request);
    res.json(saved);
};